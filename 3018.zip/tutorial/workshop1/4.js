sayHi = (name) => {
    console.log(`Hello there ${name}`)
}
sayBye=(name)=>{
    console.log('bye')
}
module.exports ={sayHi,sayBye}

  