const person={
    name:'Mandar'
}
module.exports=person