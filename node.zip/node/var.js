//using var
var tester = "hey hi";
console.log(tester);
function newFunction() {
  var tester = "i am fine";
  console.log("inside the function", tester);
}
newFunction();
console.log(tester);
//default value is getting without defining the variable
console.log(name);
var name = "sneha";

var data1 = 10;
var data1 = 20;

console.log(value1);
const value1 = 100;
