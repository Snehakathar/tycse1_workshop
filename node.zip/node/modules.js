sayHi = (name) => {
  console.log("hello from :", name);
};
module.console = sayHi;
sayBye = (name) => {
  console.log("bye from :", name);
};
module.exports = (sayHi, sayBye);
