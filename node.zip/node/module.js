const greet = require("./modules.js");
greet.sayHi("sneha");
