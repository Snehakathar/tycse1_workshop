//declaring the function
const sayHi = (firstname) => {
  console.log(firstname);
};
sayHi("Sneha");
//adddition of two no
const calc = (one, two) => {
  var ans = one + two;
  console.log(one + two);
};
calc(10, 20);
