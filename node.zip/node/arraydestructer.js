const profile =
  ((firstname = "sneha"),
  (lastname = "kathar"),
  (email = "katharsneha7@gmail.com"));
const fname = profile.firstname;
const lname = profile.lastname;
const email = profile.email;

console.log(profile);
